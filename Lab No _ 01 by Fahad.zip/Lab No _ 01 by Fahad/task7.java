import java.util.Scanner;
public class task7{

public static void main(String args[]){
Scanner input=new Scanner(System.in);
System.out.print("Enter the Radius: ");
int radius=input.nextInt();
System.out.print("Enter the height: ");
int height=input.nextInt();
double pi=3.14;
double vol=pi*radius*radius*height;
System.out.println("The volume of cylinder is: "+vol);



}
}
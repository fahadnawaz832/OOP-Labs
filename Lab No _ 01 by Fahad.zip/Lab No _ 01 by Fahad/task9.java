import java.util.Scanner;
public class task9{

public static void main(String args[]){
Scanner input=new Scanner(System.in);
System.out.print("Enter Num_01: ");
int num1=input.nextInt();
System.out.print("Enter Num_02: ");
int num2=input.nextInt();
System.out.println(" + , - , * , / ");
System.out.print("Enter Your Choice : ");
char choice=input.next().charAt(0);
switch(choice){
 case '+':
     System.out.print(" Ans: "+ (num1+num2) );
     break;
case '-':
     System.out.print(" Ans: "+ (num1-num2) );
     break;
case '*':
     System.out.print(" Ans: "+ (num1*num2) );
     break;
case '/':
     System.out.print(" Ans: "+ (num1/num2) );
     break;

default:
    System.out.print("Invalid Choice");

}
}
}
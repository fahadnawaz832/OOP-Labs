public class task3{

public static void main(String [] args){
System.out.println();
String name="Fahad";
int age=23;
double Grade=1.90;
char Gender='M';
int id=178;
String foreigner=" No ";

System.out.println("Name: "+name);
System.out.println("Age: "+age);
System.out.println("Grade: "+Grade);
System.out.println("Student ID: "+id);
System.out.println("Gender: "+Gender);
System.out.println("Foreigner: "+foreigner);

}}






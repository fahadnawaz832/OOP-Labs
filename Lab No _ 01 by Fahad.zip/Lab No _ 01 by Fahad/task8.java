import java.util.Scanner;
public class task8{

public static void main(String args[]){
Scanner input=new Scanner(System.in);
System.out.print("Enter Speed: ");
int speed=input.nextInt();
double kilo=speed*1.6;
System.out.println("Speed In Kilometer per hour is: " + kilo);

}}

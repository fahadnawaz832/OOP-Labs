import java.util.Scanner;
public class task6{

public static void main(String args[]){
Scanner input=new Scanner(System.in);
System.out.println("Enter the value in Dollars: ");
double dollars=input.nextDouble();
System.out.println("Value in rupees: "+ dollars*278.64);




}

}
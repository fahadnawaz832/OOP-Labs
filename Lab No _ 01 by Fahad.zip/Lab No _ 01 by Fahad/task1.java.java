public class output{

public static void main(String args[]){

System.out.println();

System.out.println("////////////\\\\\\\\\\\\\\\\\\\\\\\\");

System.out.println("  Student Point 8     **");

System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\////////////");

System.out.println();
System.out.print("   Lab   Bonus   Total");

System.out.println();
System.out.print("   ---   -----   -----");

System.out.println();
System.out.print("   43     7      50");

System.out.println();
System.out.print("   50     8      58");

System.out.println();
System.out.print("   39     10     49");
System.out.println();

}
}


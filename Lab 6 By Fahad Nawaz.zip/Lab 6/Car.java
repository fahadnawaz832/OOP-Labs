class Car extends Vehicle{
   int numDoors;
Car(String brand , int speed,int numDoors){
super(brand,speed);
this.numDoors=numDoors;
}

void showDetails(){
System.out.println("Brand: " + brand);
System.out.println("Speed: " + speed +" Km/h");
System.out.println("Doors: " + numDoors);


}


}
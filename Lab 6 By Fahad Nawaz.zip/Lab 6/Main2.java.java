class Main2{

public static void main(String args[]){

GraduateStudent G1 = new GraduateStudent("John Doe", 25, 101, "Artificial Intelligence");
       // System.out.print(G1);
G1.displayInfo();
}
}
class Student extends Person{
     int studentId;
Student(String name, int age, int studentId) {
        super(name, age); 
        this.studentId = studentId;

}
}
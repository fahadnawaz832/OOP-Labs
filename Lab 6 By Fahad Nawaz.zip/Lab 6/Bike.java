class Bike extends Vehicle{
   String helmetType;
Bike(String brand , int speed,String helmetType){
super(brand,speed);
this.helmetType=helmetType;
}

void showDetails(){
System.out.println("Brand: " + brand);
System.out.println("Speed: " + speed +" Km/h");
System.out.println("HelmetType: " + helmetType);


}


}
class Dog extends Animal{

void makeSound(){
System.out.print("BAU BAU...!");

}
}
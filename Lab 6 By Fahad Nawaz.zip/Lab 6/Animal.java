class Animal{
String name="Horse";
int age=20;
void makeSound(){
System.out.print("Animal Sound..!");
}
}

class Main{

public static void main(String args[]){
Car C=new Car("Toyota", 200 , 4);
System.out.println("(Car Details)");
C.showDetails();
System.out.println();
Bike B=new Bike("Honad Pridor" , 100 ,"Full Face");
System.out.println("(Bike Details)");
B.showDetails();
}

}
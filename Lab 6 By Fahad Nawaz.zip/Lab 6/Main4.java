class Main{

public static void main(String args[]){
Shape Shape=new Circle();
Shape=new Rectangle();

Shape.draw();
Shape.draw();
}
}
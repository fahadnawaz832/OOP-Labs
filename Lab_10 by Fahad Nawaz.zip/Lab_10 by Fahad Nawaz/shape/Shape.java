package shape;

abstract class Shape {

    abstract double area();
}
    interface Printable {
    void print();
    }
class Rectangle extends Shape implements Printable {
    private double width;
    private double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
    
    
    public double area() {
        return width * height;
    }

    
    public void print() {
        double rectArea = area();
        System.out.println("Area of the rectangle is: " + rectArea);
        System.out.println("This is a custom message after printing the area.");
    }
    
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(5.0, 4.0);
        rect.print();
    }   
}

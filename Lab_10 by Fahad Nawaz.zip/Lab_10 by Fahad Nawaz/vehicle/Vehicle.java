package vehicle;

public interface Vehicle {
    void start();
    void stop();

public class Car implements Vehicle{
    
    public void start() {
        System.out.println("Car is starting...");
    } 
    public void stop() {
        System.out.println("Car is stopping...");
    }
}
public class Bike implements Vehicle {   
    public void start() {
        System.out.println("Bike is starting...");
    }
    public void stop() {
        System.out.println("Bike is stopping...");
    }
}
    public static void main(String[] args) {
      Vehicle car = new Car();
        Vehicle bike = new Bike();

        System.out.println("Testing Car:");
        car.start();
        car.stop();  
        
         System.out.println("\nTesting Bike:");
        bike.start();
        bike.stop();
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicle;


public class Car implements Vehicle {
    
    public void start() {
        System.out.println("Car is starting...");
    }

    
    public void stop() {
        System.out.println("Car is stopping...");
    }
}


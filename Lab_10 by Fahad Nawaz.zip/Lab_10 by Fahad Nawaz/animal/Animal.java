package animal;
abstract class Animal {  
         abstract void makeSound();
         void eat(){
         System.out.println("Animal is Eating");
         }
 
static  class Dog extends Animal{
        void makeSound() {
            System.out.println("BHAo BHAoo....!");
        }
   } 
static class Cat extends Animal{

void makeSound(){
    System.out.println("MeAo MeAo");
}
}
    public static void main(String[] args){
        
    Animal Dog = new Dog();
        Dog.eat();
        Dog.makeSound();     
    Animal Cat = new Cat();
        Cat.eat();
        Cat.makeSound();  
    }  
}


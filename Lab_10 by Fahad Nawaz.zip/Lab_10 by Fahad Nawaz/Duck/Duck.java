interface Flyable{
       public void fly();
} 

interface Swimmable{
       public void swim();
}

class Duck implements Flyable, Swimmable {

     public void fly(){
       System.out.println("Duck is Flying..!");
            }

      public void swim(){
       System.out.println("Duck is Swiming..!");
    
}
public static void main(String [] args){
Duck duck=new Duck();
duck.fly();
duck.swim();
}
}

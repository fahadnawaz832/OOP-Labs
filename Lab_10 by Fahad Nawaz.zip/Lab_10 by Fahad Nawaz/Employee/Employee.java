abstract class Employee{
String name;
int id;

Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

public abstract double calculateSalary();
}

interface TaxPayer{
  void PayTax();
}
class FullTimeEmployee extends implements TaxPayer{
          double monthlySalary;
FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }
public double calculateSalary() {
        return monthlySalary;
    }
public void payTax() {
        double tax = monthlySalary * 0.2; 
        System.out.println("Full-Time Employee " + name + " pays tax: $" + tax);
    }


public class PartTimeEmployee extends Employee implements TaxPayer {
     double hoursWorked;
     double hourlyRate;

    public PartTimeEmployee(String name, int id, double hoursWorked, double hourlyRate) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

       public double calculateSalary() {
        return hoursWorked * hourlyRate;
    }

    
    public void payTax() {
        double salary = calculateSalary();
        double tax = salary * 0.1; // 10% tax
        System.out.println("Part-Time Employee " + name + " pays tax: $" + tax);
    }
}
 public class EmployeeSimulation {
    public static void main(String[] args) {
        FullTimeEmployee fullTimeEmp = new FullTimeEmployee("Alice", 101, 5000);
        PartTimeEmployee partTimeEmp = new PartTimeEmployee("Bob", 102, 80, 20);

        System.out.println("Full-Time Employee Salary: $" + fullTimeEmp.calculateSalary());
        fullTimeEmp.payTax();

        System.out.println("Part-Time Employee Salary: $" + partTimeEmp.calculateSalary());
        partTimeEmp.payTax();
    }
}


}
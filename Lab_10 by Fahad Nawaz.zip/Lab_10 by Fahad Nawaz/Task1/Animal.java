public abstract class Animal {
           
    abstract void sayHello();
    
public void sleep(){
    System.out.println("Animal Sleep: ZzzZzzZ...!");
}
}
class Cat extends Animal{
      
      void sayHello(){
          System.out.println("Meow Meow");

   }            
 }
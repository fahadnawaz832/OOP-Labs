class Maain{

public static void main(String [] args){
Animal dog =new Dog();
Cat c1=new Cat();
dog.sayHello();
c1.sayHello();
}
}
public class Dog extends Animal{

    void sayHello(){
        System.out.println("Dog: Bhao Bhao...!");
    }
}
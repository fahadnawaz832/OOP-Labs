import java.util.Scanner;
public class Task3{
public static void main(String [] args){
Scanner input=new Scanner(System.in);
String [] arr=new String[5];
System.out.println("Write Any Five String: ");
for(int i=0; i<5; i++){
arr[i]=input.nextLine();
}
for(String string:arr){
System.out.print(" "+string.toUpperCase());
}

}
}
import java.util.Scanner;
public class Task6{

public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write A String: ");
String string=input.nextLine();
if(string.contains("Java")|| string.contains("java")){
System.out.print("String Contains Java...!");
}
else {
System.out.print("String Doesn't Contains Java..!");
}
}
}
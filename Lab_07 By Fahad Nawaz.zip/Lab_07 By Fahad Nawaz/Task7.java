import java.util.Scanner;
public class Task7{

public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write A String: ");
String string=input.nextLine();
String Remove=string.replace(' ',' ');
System.out.print("Space removed: "+Remove);


}
}
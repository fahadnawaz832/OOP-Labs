import java.util.Scanner;
public class Task1{
 
public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write a String: ");
String string=input.nextLine();

if(string.isEmpty()){
    System.out.println("String Is Empty..!");

}

else{
   System.out.println("String Isn't Empty..!");
    
}




}
}
import java.util.Scanner;
public class Task5{
public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write Any String Ends With Hello or hello: ");
String string=input.nextLine();
if(string.endsWith("Hello") || string.endsWith("hello")){
System.out.print("String Ends With Hello Or hello..!");
}
else{
System.out.print("String Doesn't Ends With Hello Or hello..!");
}
}
}
import java.util.Scanner;
public class Task8 {

   
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Write a String: ");
        String string=input.nextLine();
        String[] words = string.split(" ");
           int wordCount=0;
           for (String word : words) {
            System.out.println(word); 
            wordCount++;
        }
           System.out.println("\nTotal number of words: " + wordCount);
    }
    
}

import java.util.Scanner;

public class Task2{

public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write a String: ");
String string =input.nextLine();
int index=string.indexOf('a')
System.out.print("Index of first occurrence of 'a': " + index");
}
 }
  }
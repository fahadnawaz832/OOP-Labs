import java.util.Scanner;
public class Task4{

public static void main(String [] args){
Scanner input=new Scanner(System.in);
System.out.print("Write Any String Starts With Hello or hello: ");
String string=input.nextLine();
if(string.startsWith("Hello" )|| string.startsWith("hello")){
   System.out.print("String Starts With Hello or hello....!");
}
else{
  System.out.print("String Doesn't Starts With Hello or hello..!");

}
}
}


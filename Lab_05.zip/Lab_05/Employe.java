class Employe{
      String name;
      int ID;
      double salary;

Employe(String name , int ID , double salary){
this.name=name;
this.ID=ID;
this.salary=salary;

}
public void increaseSalary(double amount){
amount+=salary;
System.out.println("Increased Salary: "+amount);

}

public void calculateAnnualSalary(){
System.out.println("Anual Salary is: "+salary*12);

}

public void displayDetails(){
      System.out.println("Employe Name: "+name);
      System.out.println("Employe ID: "+ID);
      System.out.println("Employe Salary: "+salary);

}
public static void main(String args[]){
 Employe e1=new Employe("Fahad",178,8000);

e1.increaseSalary(2000);
e1.displayDetails();
e1.calculateAnnualSalary();




}



}
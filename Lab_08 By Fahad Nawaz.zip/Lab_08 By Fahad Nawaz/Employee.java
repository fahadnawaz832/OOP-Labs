
package employee;


public class Employee {
    int calBonus(int salary){
    return (10*salary/100);
   }
    
    int calBonus(int salary,int extra_hours){
    return (10*salary/100)*500;
   }
    public static void main(String[] args) {
      Employee E1=new Employee();
        System.out.println("Bonus Salary: "+E1.calBonus(50000));
         System.out.println("Bonus Salary: "+E1.calBonus(50000, 3));
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package temperature;


public class Temperature {
    double celsius;

    void setCelsius(double celsius) {
        this.celsius = celsius;
    }

    double getFahrenheit() {
        return celsius * 9 / 5 + 32;
    }

    public static void main(String[] args) {
        Temperature temp = new Temperature();
        temp.setCelsius(25);  // example value
        System.out.println("Fahrenheit: " + temp.getFahrenheit());
    }
}

class Dog extends Animal{
 void makeSound(){
    //super.makeSound();
System.out.println("BhAoO BhAoO.....!");
}

}
class Cat{
void makeSound(){
//super.makeSound();
System.out.println("MeAw MeAw..!");
}
}
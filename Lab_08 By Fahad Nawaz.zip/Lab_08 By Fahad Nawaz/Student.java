public class Student {
     private String name;
     private int rollNumber;
     private char grade;
    
     String getName(){
     return name;
     }
     
     void setName(String name){
         this.name=name;
     }
     int getrollNumber(){
     return rollNumber;
     }
     void setrollNumber(int rollNumber){
      this.rollNumber=rollNumber;
     }
     
     char getGrade(){
     return grade;
     }
     
     void setGrade(char grade){
      this.grade=grade;
     }
     
     void displayDetails(){
         System.out.println("Name: "+name);
         System.out.println("ROll N0: "+rollNumber);
         System.out.println("Grade: "+grade);

     }
    public static void main(String[] args) {
       Student S1=new Student();
       S1.setName("Alice");
       S1.setrollNumber(101);
       S1.setGrade('A');
       S1.displayDetails();
    }
    
}

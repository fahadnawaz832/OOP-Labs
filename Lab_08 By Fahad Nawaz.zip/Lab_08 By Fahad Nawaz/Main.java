class Main{
 public static void main(String [] args){
Animal A1=new Animal();
Dog D1=new Dog();
Cat C1=new Cat();
A1.makeSound();
D1.makeSound();
C1.makeSound();
}

}
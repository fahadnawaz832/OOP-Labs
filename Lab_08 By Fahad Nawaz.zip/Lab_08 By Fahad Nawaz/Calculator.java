
package calculator;


public class Calculator {
      int add(int a, int b){
          return a+b;
      }
  
  double add(double a, double b){
          return a+b;
      }    
  String add(String a, String  b){
          return a+b;
      }
    public static void main(String[] args) {
     Calculator C1=new Calculator();
        System.out.println("INT : "+C1.add(5,3));
        System.out.println("DOUBLE : "+C1.add(2.5, 3.7));
        System.out.println("STRING: "+C1.add("Hello","World"));
    }
    
}
